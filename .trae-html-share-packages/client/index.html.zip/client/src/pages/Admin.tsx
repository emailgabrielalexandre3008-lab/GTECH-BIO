import { useEffect, useMemo, useState, type FormEvent } from "react";
import { Activity, ArrowLeft, BarChart3, Check, CheckCircle2, ClipboardList, ExternalLink, FileText, Image, LayoutDashboard, Link2, LogOut, Megaphone, Pencil, Plus, Quote, Settings, ShieldCheck, Smartphone, Star, Trash2, UploadCloud, Users, X } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { clearAdminSessionToken, getAdminSessionHeaders, saveAdminSessionToken } from "@/lib/admin-session";

type AdminSessionState = { checked: boolean; authenticated: boolean; email: string };
type Tab = "dashboard" | "branding" | "editor" | "links" | "simulator" | "orders" | "clients" | "promotions" | "feedback" | "frontals-import" | "batteries-import" | "analytics" | "settings" | "security";
type LoginResponse = { authenticated?: boolean; email?: string; adminToken?: string; error?: string };
type ContentForm = { kind: string; slug: string; title: string; subtitle: string; body: string; url: string; dataJson: string; active: boolean; sortOrder: number };

const emptyFeedback = { customerName: "", rating: 5, comment: "", reviewDate: "", source: "Google", published: false };
const emptyContent: ContentForm = { kind: "link", slug: "", title: "", subtitle: "", body: "", url: "", dataJson: "", active: true, sortOrder: 0 };
const nav: { id: Tab; label: string; icon: typeof LayoutDashboard }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "branding", label: "Logo e identidade", icon: Image },
  { id: "editor", label: "Editor do Biolink", icon: Smartphone },
  { id: "links", label: "Botões e Links", icon: Link2 },
  { id: "simulator", label: "Simulador", icon: Quote },
  { id: "orders", label: "Pedidos", icon: ClipboardList },
  { id: "clients", label: "Clientes", icon: Users },
  { id: "promotions", label: "Promoções", icon: Megaphone },
  { id: "feedback", label: "Avaliações", icon: Star },
  { id: "frontals-import", label: "Importar telas", icon: UploadCloud },
  { id: "batteries-import", label: "Importar baterias", icon: Smartphone },
  { id: "analytics", label: "Analytics", icon: BarChart3 },
  { id: "settings", label: "Configurações", icon: Settings },
  { id: "security", label: "Segurança", icon: ShieldCheck },
];

async function readJson<T>(response: Response) { return (await response.json().catch(() => ({}))) as T; }

export default function Admin() {
  const [session, setSession] = useState<AdminSessionState>({ checked: false, authenticated: false, email: "" });
  const [tab, setTab] = useState<Tab>("dashboard");
  const [loginForm, setLoginForm] = useState({ email: "", password: "" });
  const [loginError, setLoginError] = useState("");
  const [loginPending, setLoginPending] = useState(false);
  const [feedbackEditingId, setFeedbackEditingId] = useState<number | null>(null);
  const [feedbackForm, setFeedbackForm] = useState(emptyFeedback);
  const [contentEditingId, setContentEditingId] = useState<number | null>(null);
  const [contentForm, setContentForm] = useState<ContentForm>(emptyContent);

  useEffect(() => {
    let active = true;
    fetch("/api/admin/session", { credentials: "include", headers: getAdminSessionHeaders() }).then((response) => readJson<{ authenticated: boolean; email?: string }>(response)).then((data) => {
      if (active) setSession({ checked: true, authenticated: Boolean(data.authenticated), email: data.email ?? "" });
    }).catch(() => { if (active) setSession({ checked: true, authenticated: false, email: "" }); });
    return () => { active = false; };
  }, []);

  const contentKind = tab === "editor" ? "section" : tab === "links" ? "link" : tab === "simulator" ? "repair" : tab === "promotions" ? "promotion" : tab === "settings" ? "settings" : undefined;
  const feedbackQuery = trpc.feedback.adminList.useQuery(undefined, { enabled: session.authenticated });
  const contentQuery = trpc.content.adminList.useQuery(contentKind ? { kind: contentKind } : undefined, { enabled: session.authenticated && Boolean(contentKind) });
  const quotesQuery = trpc.quotes.adminList.useQuery(undefined, { enabled: session.authenticated });
  const analyticsQuery = trpc.analytics.adminList.useQuery(undefined, { enabled: session.authenticated });
  const createFeedback = trpc.feedback.create.useMutation({ onSuccess: () => { feedbackQuery.refetch(); resetFeedback(); } });
  const updateFeedback = trpc.feedback.update.useMutation({ onSuccess: () => { feedbackQuery.refetch(); resetFeedback(); } });
  const removeFeedback = trpc.feedback.remove.useMutation({ onSuccess: () => feedbackQuery.refetch() });
  const createContent = trpc.content.create.useMutation({ onSuccess: () => { contentQuery.refetch(); resetContent(); } });
  const updateContent = trpc.content.update.useMutation({ onSuccess: () => { contentQuery.refetch(); resetContent(); } });
  const removeContent = trpc.content.remove.useMutation({ onSuccess: () => contentQuery.refetch() });
  const updateQuoteStatus = trpc.quotes.updateStatus.useMutation({ onSuccess: () => quotesQuery.refetch() });

  async function handleLogin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setLoginPending(true); setLoginError("");
    try {
      const response = await fetch("/api/admin/login", { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify(loginForm) });
      const data = await readJson<LoginResponse>(response);
      if (!response.ok || !data.authenticated) { setLoginError(data.error ?? "Não foi possível entrar."); return; }
      saveAdminSessionToken(data.adminToken);
      setSession({ checked: true, authenticated: true, email: data.email ?? loginForm.email.trim().toLowerCase() }); setLoginForm({ email: loginForm.email, password: "" });
    } catch { setLoginError("Não foi possível conectar ao painel. Tente novamente."); } finally { setLoginPending(false); }
  }

  async function handleLogout() { await fetch("/api/admin/logout", { method: "POST", credentials: "include", headers: getAdminSessionHeaders() }).catch(() => undefined); clearAdminSessionToken(); setSession({ checked: true, authenticated: false, email: "" }); }
  function resetFeedback() { setFeedbackEditingId(null); setFeedbackForm(emptyFeedback); }
  function resetContent() { setContentEditingId(null); setContentForm({ ...emptyContent, kind: contentKind ?? "link" }); }
  function editContent(item: NonNullable<typeof contentQuery.data>[number]) { setContentEditingId(item.id); setContentForm({ kind: item.kind, slug: item.slug, title: item.title, subtitle: item.subtitle ?? "", body: item.body ?? "", url: item.url ?? "", dataJson: item.dataJson ?? "", active: item.active === 1, sortOrder: item.sortOrder }); }

  const feedbackAverage = useMemo(() => { const list = feedbackQuery.data ?? []; return list.length ? (list.reduce((sum, item) => sum + item.rating, 0) / list.length).toFixed(1) : "—"; }, [feedbackQuery.data]);
  const eventCounts = useMemo(() => (analyticsQuery.data ?? []).reduce<Record<string, number>>((acc, item) => { acc[item.eventName] = (acc[item.eventName] ?? 0) + 1; return acc; }, {}), [analyticsQuery.data]);
  const clients = useMemo(() => { const seen = new Map<string, { name: string; phone: string; last: string; total: number }>(); (quotesQuery.data ?? []).forEach((item) => { const key = `${item.customerName}|${item.phone ?? ""}`; const current = seen.get(key); seen.set(key, { name: item.customerName, phone: item.phone ?? "Não informado", last: item.createdAt.toLocaleString("pt-BR"), total: (current?.total ?? 0) + 1 }); }); return Array.from(seen.values()); }, [quotesQuery.data]);

  if (!session.checked) return <div className="admin-state">Verificando acesso seguro...</div>;
  if (!session.authenticated) return <main className="admin-login-page"><form className="admin-login-card" onSubmit={handleLogin}><ShieldCheck size={30} /><span className="admin-eyebrow">G-TECH / ÁREA RESTRITA</span><h1>Painel administrativo</h1><p>Entre com o e-mail e a senha administrativa para gerenciar o conteúdo real da G-Tech.</p><label>E-mail<input type="email" value={loginForm.email} onChange={(event) => setLoginForm({ ...loginForm, email: event.target.value })} placeholder="seu@email.com" autoComplete="username" required /></label><label>Senha<input type="password" value={loginForm.password} onChange={(event) => setLoginForm({ ...loginForm, password: event.target.value })} placeholder="Sua senha" autoComplete="current-password" required /></label>{loginError && <div className="admin-form-error" role="alert">{loginError}</div>}<button className="admin-button admin-button--primary" type="submit" disabled={loginPending}>{loginPending ? "Entrando..." : "Entrar no painel"}</button><a className="admin-button admin-button--secondary" href="/">Voltar ao Link na Bio</a></form></main>;

  const currentLabel = nav.find((item) => item.id === tab)?.label ?? "Dashboard";
  return <main className="admin-shell"><aside className="admin-sidebar"><div className="admin-brand"><span>G-TECH</span><small>CONTROL CENTER</small></div><nav aria-label="Módulos administrativos">{nav.map(({ id, label, icon: Icon }) => <button key={id} className={tab === id ? "is-active" : ""} onClick={() => { setTab(id); resetContent(); }}><Icon size={16} />{label}</button>)}</nav><div className="admin-sidebar__bottom"><small>{session.email}</small><button onClick={handleLogout}><LogOut size={15} /> Sair</button></div></aside><section className="admin-workspace"><header className="admin-workspace__header"><div><span className="admin-eyebrow">G-TECH / PAINEL ADMINISTRATIVO</span><h1>{currentLabel}</h1><p>Gerencie a operação da G-Tech pelo celular ou computador.</p></div><div className="admin-header__actions"><a className="admin-button admin-button--secondary" href="/"><ArrowLeft size={15} /> Link na Bio</a><button className="admin-button admin-button--secondary" onClick={handleLogout}><LogOut size={15} /> Sair</button></div></header><div className="admin-mobile-nav">{nav.map(({ id, label }) => <button key={id} className={tab === id ? "is-active" : ""} onClick={() => setTab(id)}>{label}</button>)}</div>{tab === "dashboard" && <Dashboard quotes={quotesQuery.data ?? []} feedbackCount={feedbackQuery.data?.length ?? 0} analytics={eventCounts} />} {tab === "branding" && <BrandingModule />} {tab === "feedback" && <FeedbackModule data={feedbackQuery.data ?? []} average={feedbackAverage} form={feedbackForm} setForm={setFeedbackForm} editingId={feedbackEditingId} setEditingId={setFeedbackEditingId} reset={resetFeedback} create={createFeedback} update={updateFeedback} remove={removeFeedback} />} {tab === "frontals-import" && <FrontalsImportModule />} {tab === "batteries-import" && <FrontalsImportModule category="batteries" />} {contentKind && <ContentModule kind={contentKind} data={contentQuery.data ?? []} form={contentForm} setForm={setContentForm} editingId={contentEditingId} edit={editContent} reset={resetContent} create={createContent} update={updateContent} remove={removeContent} />} {tab === "orders" && <OrdersModule data={quotesQuery.data ?? []} updateStatus={updateQuoteStatus} />} {tab === "clients" && <ClientsModule data={clients} />} {tab === "analytics" && <AnalyticsModule data={analyticsQuery.data ?? []} counts={eventCounts} />} {tab === "security" && <SecurityModule email={session.email} />} </section></main>;
}

function Dashboard({ quotes, feedbackCount, analytics }: { quotes: any[]; feedbackCount: number; analytics: Record<string, number> }) { const cards = [{ label: "Pedidos", value: quotes.length, icon: ClipboardList }, { label: "Novos", value: quotes.filter((item: any) => item.status === "new").length, icon: Activity }, { label: "Avaliações", value: feedbackCount, icon: Star }, { label: "Eventos", value: Object.values(analytics).reduce((a, b) => a + b, 0), icon: BarChart3 }]; return <section className="admin-panel"><div className="admin-kpi-grid">{cards.map(({ label, value, icon: Icon }) => <article className="admin-kpi" key={label}><Icon size={18} /><span>{label}</span><strong>{value}</strong><small>Dados registrados no sistema</small></article>)}</div><div className="admin-card"><div className="admin-card__head"><div><span className="admin-eyebrow">VISÃO OPERACIONAL</span><h2>Próximas ações</h2></div></div><div className="admin-next-grid"><div><ClipboardList size={18} /><strong>Pedidos de orçamento</strong><p>Acompanhe solicitações reais enviadas pelo simulador público e avance o status do atendimento.</p></div><div><Link2 size={18} /><strong>Conteúdo da página</strong><p>Edite links, promoções, serviços e configurações sem alterar o código.</p></div><div><BarChart3 size={18} /><strong>Analytics</strong><p>Os números aparecem somente depois que eventos reais forem registrados.</p></div></div></div></section>; }

function ContentModule({ kind, data, form, setForm, editingId, edit, reset, create, update, remove }: { kind: string; data: any[]; form: ContentForm; setForm: (value: ContentForm) => void; editingId: number | null; edit: (item: any) => void; reset: () => void; create: { mutate: (value: any) => void; isPending: boolean }; update: { mutate: (value: any) => void; isPending: boolean }; remove: { mutate: (value: { id: number }) => void }; }) { const labels: Record<string, string> = { section: "Seções do Biolink", link: "Botões e links", repair: "Marcas, modelos e reparos", promotion: "Promoções", settings: "Configurações da empresa" }; const save = () => { const payload = { ...form, subtitle: form.subtitle || undefined, body: form.body || undefined, url: form.url || undefined, dataJson: form.dataJson || undefined }; if (editingId) update.mutate({ id: editingId, ...payload }); else create.mutate(payload); }; return <section className="admin-panel"><div className="admin-grid admin-grid--workspace"><div className="admin-card"><div className="admin-card__head"><div><span className="admin-eyebrow">{editingId ? "EDITAR REGISTRO" : "NOVO REGISTRO"}</span><h2>{editingId ? "Atualizar" : "Cadastrar"} {labels[kind]?.toLowerCase()}</h2></div>{editingId && <button className="admin-icon-button" onClick={reset} aria-label="Cancelar edição"><X size={17} /></button>}</div><label>Identificador<input value={form.slug} onChange={(event) => setForm({ ...form, slug: event.target.value })} placeholder="ex.: whatsapp, bateria, garantia" /></label><label>Título<input value={form.title} onChange={(event) => setForm({ ...form, title: event.target.value })} placeholder="Nome exibido" /></label><label>Texto secundário<input value={form.subtitle} onChange={(event) => setForm({ ...form, subtitle: event.target.value })} placeholder="Descrição curta" /></label><label>Conteúdo<textarea value={form.body} onChange={(event) => setForm({ ...form, body: event.target.value })} placeholder="Descrição, observações ou regras" rows={4} /></label><label>URL<input value={form.url} onChange={(event) => setForm({ ...form, url: event.target.value })} placeholder="https://..." /></label>{kind === "settings" && <label>Dados estruturados (JSON)<textarea value={form.dataJson} onChange={(event) => setForm({ ...form, dataJson: event.target.value })} placeholder='{"brand":"G-Tech Assistência Técnica"}' rows={6} /></label>}<div className="admin-form-row"><label>Ordem<input type="number" value={form.sortOrder} onChange={(event) => setForm({ ...form, sortOrder: Number(event.target.value) })} /></label><label className="admin-check"><input type="checkbox" checked={form.active} onChange={(event) => setForm({ ...form, active: event.target.checked })} /> Ativo</label></div><button className="admin-button admin-button--primary" disabled={!form.slug.trim() || !form.title.trim() || create.isPending || update.isPending} onClick={save}>{editingId ? <Check size={16} /> : <Plus size={16} />}{create.isPending || update.isPending ? "Salvando..." : editingId ? "Salvar alterações" : "Cadastrar"}</button></div><div className="admin-card"><div className="admin-card__head"><div><span className="admin-eyebrow">REGISTROS PERSISTENTES</span><h2>{labels[kind]}</h2></div><strong className="admin-stat">{data.length}</strong></div>{data.length ? <div className="admin-review-list">{data.map((item) => <article className="admin-review" key={item.id}><div className="admin-review__top"><strong>{item.title}</strong><span className={item.active ? "status status--live" : "status"}>{item.active ? "Ativo" : "Inativo"}</span></div><small>{item.slug}{item.url ? ` · ${item.url}` : ""}</small>{item.subtitle && <p>{item.subtitle}</p>}<div className="admin-review__actions"><button onClick={() => edit(item)}><Pencil size={14} /> Editar</button><button className="danger" onClick={() => { if (window.confirm("Remover este registro?")) remove.mutate({ id: item.id }); }}><Trash2 size={14} /> Remover</button></div></article>)}</div> : <div className="admin-empty"><FileText size={24} /><h3>Nenhum registro</h3><p>Cadastre o primeiro item. Nada será criado automaticamente.</p></div>}</div></div></section>; }

function FeedbackModule({ data, average, form, setForm, editingId, setEditingId, reset, create, update, remove }: any) { const save = () => { if (editingId) update.mutate({ id: editingId, ...form }); else create.mutate(form); }; return <section className="admin-panel"><div className="admin-grid admin-grid--workspace"><div className="admin-card"><div className="admin-card__head"><div><span className="admin-eyebrow">{editingId ? "EDITAR REGISTRO" : "NOVO REGISTRO"}</span><h2>{editingId ? "Atualizar avaliação" : "Cadastrar avaliação"}</h2></div></div><label>Nome do cliente<input value={form.customerName} onChange={(event) => setForm({ ...form, customerName: event.target.value })} placeholder="Nome real" /></label><label>Nota<div className="admin-rating-input">{[1, 2, 3, 4, 5].map((value) => <button type="button" key={value} className={value <= form.rating ? "is-active" : ""} onClick={() => setForm({ ...form, rating: value })} aria-label={`${value} estrelas`}><Star size={22} fill="currentColor" /></button>)}</div></label><label>Comentário<textarea value={form.comment} onChange={(event) => setForm({ ...form, comment: event.target.value })} placeholder="Cole o comentário real" rows={5} /></label><div className="admin-form-row"><label>Data<input value={form.reviewDate} onChange={(event) => setForm({ ...form, reviewDate: event.target.value })} placeholder="02/11/2026" /></label><label>Fonte<input value={form.source} onChange={(event) => setForm({ ...form, source: event.target.value })} /></label></div><label className="admin-check"><input type="checkbox" checked={form.published} onChange={(event) => setForm({ ...form, published: event.target.checked })} /> Publicar</label><button className="admin-button admin-button--primary" disabled={form.customerName.trim().length < 2 || form.comment.trim().length < 3} onClick={save}>{editingId ? "Salvar alterações" : "Cadastrar avaliação"}</button></div><div className="admin-card"><div className="admin-card__head"><div><span className="admin-eyebrow">REGISTROS REAIS</span><h2>Avaliações</h2></div><div className="admin-stat"><strong>{average}</strong><span>{data.length} registros</span></div></div>{data.length ? <div className="admin-review-list">{data.map((item: any) => <article className="admin-review" key={item.id}><div className="admin-review__top"><strong>{item.customerName}</strong><span className={item.published ? "status status--live" : "status"}>{item.published ? "Publicado" : "Rascunho"}</span></div><div className="admin-stars">{Array.from({ length: 5 }, (_, index) => <Star key={index} size={14} fill={index < item.rating ? "currentColor" : "none"} />)}</div><p>{item.comment}</p><small>{item.source}{item.reviewDate ? ` · ${item.reviewDate}` : ""}</small><div className="admin-review__actions"><button onClick={() => { setEditingId(item.id); setForm({ customerName: item.customerName, rating: item.rating, comment: item.comment, reviewDate: item.reviewDate ?? "", source: item.source, published: item.published === 1 }); }}><Pencil size={14} /> Editar</button><button className="danger" onClick={() => { if (window.confirm("Remover esta avaliação?")) remove.mutate({ id: item.id }); }}><Trash2 size={14} /> Remover</button></div></article>)}</div> : <div className="admin-empty"><Star size={24} /><h3>Nenhuma avaliação cadastrada</h3><p>Adicione apenas avaliações reais. Nada será inventado automaticamente.</p></div>}</div></div></section>; }

function OrdersModule({ data, updateStatus }: any) { const labels: Record<string, string> = { new: "Novo", in_review: "Em análise", awaiting_approval: "Aguardando aprovação", approved: "Aprovado", in_repair: "Em reparo", completed: "Concluído", delivered: "Entregue", cancelled: "Cancelado" }; return <section className="admin-panel"><div className="admin-card"><div className="admin-card__head"><div><span className="admin-eyebrow">PEDIDOS REGISTRADOS</span><h2>Orçamentos e atendimentos</h2></div><strong className="admin-stat">{data.length}</strong></div>{data.length ? <div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>Cliente</th><th>Aparelho</th><th>Defeito</th><th>Data</th><th>Status</th></tr></thead><tbody>{data.map((item: any) => <tr key={item.id}><td><strong>{item.customerName}</strong><small>{item.phone || "Contato não informado"}</small></td><td>{item.brand} · {item.model}</td><td>{item.issue}</td><td>{item.createdAt.toLocaleDateString("pt-BR")}</td><td><select value={item.status} onChange={(event) => updateStatus.mutate({ id: item.id, status: event.target.value })}>{Object.entries(labels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></td></tr>)}</tbody></table></div> : <div className="admin-empty"><ClipboardList size={24} /><h3>Nenhum pedido recebido</h3><p>Quando um cliente enviar o simulador, o pedido aparecerá aqui.</p></div>}</div></section>; }

function ClientsModule({ data }: { data: { name: string; phone: string; last: string; total: number }[] }) { return <section className="admin-panel"><div className="admin-card"><div className="admin-card__head"><div><span className="admin-eyebrow">CRM DERIVADO DOS PEDIDOS</span><h2>Clientes</h2></div><strong className="admin-stat">{data.length}</strong></div>{data.length ? <div className="admin-review-list">{data.map((item) => <article className="admin-review" key={`${item.name}-${item.phone}`}><div className="admin-review__top"><strong>{item.name}</strong><span className="status status--live">{item.total} pedido(s)</span></div><p>{item.phone}</p><small>Último pedido registrado: {item.last}</small></article>)}</div> : <div className="admin-empty"><Users size={24} /><h3>Nenhum cliente ainda</h3><p>Os clientes serão formados a partir dos pedidos reais de orçamento.</p></div>}</div></section>; }

function AnalyticsModule({ data, counts }: { data: any[]; counts: Record<string, number> }) { return <section className="admin-panel"><div className="admin-kpi-grid">{Object.entries(counts).map(([name, count]) => <article className="admin-kpi" key={name}><Activity size={18} /><span>{name}</span><strong>{count}</strong><small>eventos registrados</small></article>)}</div><div className="admin-card"><div className="admin-card__head"><div><span className="admin-eyebrow">SEM DADOS FICTÍCIOS</span><h2>Últimos eventos</h2></div></div>{data.length ? <div className="admin-review-list">{data.slice(0, 40).map((item) => <article className="admin-review" key={item.id}><div className="admin-review__top"><strong>{item.eventName}</strong><small>{item.createdAt.toLocaleString("pt-BR")}</small></div><p>{item.path || "/"}</p></article>)}</div> : <div className="admin-empty"><BarChart3 size={24} /><h3>Analytics aguardando dados</h3><p>O painel só exibe números depois que eventos reais forem registrados.</p></div>}</div></section>; }

function SecurityModule({ email }: { email: string }) { return <section className="admin-panel"><div className="admin-card security-card"><ShieldCheck size={28} /><span className="admin-eyebrow">SESSÃO PROTEGIDA</span><h2>Acesso administrativo ativo</h2><p>Você está conectado como <strong>{email}</strong>. A sessão usa cookie seguro e expiração configurada no servidor. Google Meu Negócio e API Google continuam deliberadamente fora desta etapa.</p><div className="security-list"><span><Check size={15} /> Credencial fora do frontend</span><span><Check size={15} /> Sessão persistente no banco</span><span><Check size={15} /> Procedures administrativas protegidas</span></div></div></section>; }

function BrandingModule() {
  const brandingQuery = trpc.content.adminList.useQuery({ kind: "branding" });
  const createBranding = trpc.content.create.useMutation({ onSuccess: () => brandingQuery.refetch() });
  const updateBranding = trpc.content.update.useMutation({ onSuccess: () => brandingQuery.refetch() });
  const current = brandingQuery.data?.find((item) => item.slug === "logo");
  const parsed = (() => { try { return current?.dataJson ? JSON.parse(current.dataJson) as { logoUrl?: string; scale?: number; positionX?: number; positionY?: number } : {}; } catch { return {}; } })();
  const [file, setFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState("");
  const [logoUrl, setLogoUrl] = useState(parsed.logoUrl ?? "");
  const [scale, setScale] = useState(Number(parsed.scale) || 1);
  const [positionX, setPositionX] = useState(Number(parsed.positionX) || 0);
  const [positionY, setPositionY] = useState(Number(parsed.positionY) || 0);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  useEffect(() => { setLogoUrl(parsed.logoUrl ?? ""); setScale(Number(parsed.scale) || 1); setPositionX(Number(parsed.positionX) || 0); setPositionY(Number(parsed.positionY) || 0); }, [current?.id]);
  useEffect(() => { if (!file) { setFilePreview(""); return; } const url = URL.createObjectURL(file); setFilePreview(url); return () => URL.revokeObjectURL(url); }, [file]);

  async function uploadLogo() {
    if (!file) return logoUrl;
    const session = await fetch("/api/admin/session", { credentials: "include", headers: getAdminSessionHeaders() }).then((response) => response.json());
    if (!session.authenticated || !session.actionTicket) throw new Error("Sua sessão administrativa expirou.");
    const response = await fetch("/api/admin/branding/logo", { method: "POST", credentials: "include", headers: { "Content-Type": file.type, "X-File-Name": file.name, "X-Admin-Action-Ticket": session.actionTicket }, body: await file.arrayBuffer() });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || "Não foi possível enviar a logo.");
    return data.url as string;
  }
  async function save() {
    setError(""); setMessage("");
    try {
      const nextLogoUrl = await uploadLogo();
      if (!nextLogoUrl) throw new Error("Selecione uma imagem JPG ou PNG.");
      const dataJson = JSON.stringify({ logoUrl: nextLogoUrl, scale, positionX, positionY });
      const payload = { kind: "branding", slug: "logo", title: "Logo pública", subtitle: "Logo do Link na Bio", body: "Ajuste circular da marca G-Tech", url: "", dataJson, active: true, sortOrder: 0 };
      if (current) updateBranding.mutate({ id: current.id, ...payload }); else createBranding.mutate(payload);
      setLogoUrl(nextLogoUrl); setFile(null); setMessage("Logo salva. Atualize o Link na Bio para conferir o resultado.");
    } catch (caught) { setError(caught instanceof Error ? caught.message : "Não foi possível salvar a identidade visual."); }
  }
  const previewStyle = { "--logo-scale": scale, "--logo-x": `${positionX}%`, "--logo-y": `${positionY}%` } as React.CSSProperties;
  const previewSrc = filePreview || logoUrl.trim();
  return <section className="admin-panel branding-panel"><div className="admin-grid admin-grid--workspace"><div className="admin-card"><div className="admin-card__head"><div><span className="admin-eyebrow">IDENTIDADE VISUAL</span><h2>Logo do Link na Bio</h2></div><Image size={21} /></div><p className="admin-muted">Envie uma imagem JPG ou PNG. O sistema aplica uma máscara circular sem borda preta e permite ajustar escala e centralização.</p><label className="supplier-dropzone branding-upload"><input type="file" accept="image/jpeg,image/png,.jpg,.jpeg,.png" onChange={(event) => setFile(event.target.files?.[0] ?? null)} />{file ? <><strong>{file.name}</strong><small>{(file.size / 1024).toFixed(1)} KB · pronto para upload</small></> : <><strong>Escolher logo</strong><small>JPG ou PNG · máximo 5 MB</small></>}</label><div className="branding-controls"><label>Escala <output>{scale.toFixed(2)}×</output><input type="range" min="0.7" max="1.8" step="0.05" value={scale} onChange={(event) => setScale(Number(event.target.value))} /></label><label>Horizontal <output>{positionX}%</output><input type="range" min="-50" max="50" step="1" value={positionX} onChange={(event) => setPositionX(Number(event.target.value))} /></label><label>Vertical <output>{positionY}%</output><input type="range" min="-50" max="50" step="1" value={positionY} onChange={(event) => setPositionY(Number(event.target.value))} /></label></div><button className="admin-button admin-button--primary" disabled={createBranding.isPending || updateBranding.isPending} onClick={save}>{createBranding.isPending || updateBranding.isPending ? "Salvando..." : "Salvar logo e posicionamento"}</button>{message && <p className="supplier-success"><CheckCircle2 size={15} /> {message}</p>}{error && <p className="admin-form-error">{error}</p>}</div><div className="admin-card branding-preview-card"><div className="admin-card__head"><div><span className="admin-eyebrow">PRÉVIA</span><h2>Sem borda externa</h2></div></div><div className="branding-preview-stage"><div className="branding-preview-frame">{previewSrc ? <img src={previewSrc} alt="Prévia da logo" style={previewStyle} /> : <Image size={30} />}</div></div><p className="admin-muted">A área azul representa o círculo final. Ajuste até a marca ficar centralizada e toque em salvar.</p></div></div></section>;
}


type FrontalsImportRow = { rowNumber: number; sheetName: string; brand: string; model: string; quality: string | null; supplierCost: number | null; estimatedPrice: number | null; rawValue: string; valid: boolean; issue?: string };
type FrontalsImportSummary = { importId: number; fileName: string; status: string; rowsTotal: number; validRows: number; invalidRows: number; duplicateRows: number; brands: string[]; models: number; sheetsRead: string[]; preview: FrontalsImportRow[] };

function FrontalsImportModule({ category = "frontals" }: { category?: "frontals" | "batteries" }) {
  const isBattery = category === "batteries";
  const apiBase = `/api/admin/supplier/${category}`;
  const [file, setFile] = useState<File | null>(null);
  const [imports, setImports] = useState<any[]>([]);
  const [preview, setPreview] = useState<FrontalsImportSummary | null>(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  async function supplierFetch(input: RequestInfo | URL, init: RequestInit = {}) {
    const sessionResponse = await fetch("/api/admin/session", { credentials: "include", headers: getAdminSessionHeaders() });
    const session = await sessionResponse.json().catch(() => ({}));
    if (!session.authenticated || !session.actionTicket) throw new Error("Sua sessão administrativa expirou. Recarregue o painel e entre novamente.");
    const headers = new Headers(init.headers);
    headers.set("X-Admin-Action-Ticket", session.actionTicket);
    return fetch(input, { ...init, credentials: "include", headers });
  }

  async function loadHistory() {
    const response = await supplierFetch(`${apiBase}/imports`);
    const data = await response.json().catch(() => ({}));
    if (response.ok) setImports(data.imports ?? []);
  }
  useEffect(() => { void loadHistory(); }, []);

  async function upload() {
    if (!file) return;
    setLoading(true); setMessage(""); setError("");
    try {
      const response = await supplierFetch(`${apiBase}/import`, { method: "POST", headers: { "Content-Type": file.type || "application/octet-stream", "X-File-Name": file.name }, body: await file.arrayBuffer() });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || "Não foi possível importar o arquivo.");
      setPreview(data); setFile(null); setMessage("Arquivo lido. Confira a prévia antes de aprovar os preços."); await loadHistory();
    } catch (caught) { setError(caught instanceof Error ? caught.message : "Não foi possível importar o arquivo."); } finally { setLoading(false); }
  }

  async function inspect(id: number) {
    setLoading(true); setError("");
    try { const response = await supplierFetch(`${apiBase}/imports/${id}`); const data = await response.json(); if (!response.ok) throw new Error(data.error); setPreview({ importId: data.id, fileName: data.fileName, status: data.status, rowsTotal: data.rowsTotal, validRows: data.validRows, invalidRows: data.invalidRows, duplicateRows: data.duplicateRows, brands: [], models: 0, sheetsRead: [], preview: data.preview }); } catch (caught) { setError(caught instanceof Error ? caught.message : "Não foi possível abrir a prévia."); } finally { setLoading(false); }
  }

  async function approve(id: number) {
    if (!window.confirm("Aprovar esta atualização? Os custos válidos passarão a alimentar o catálogo de frontais.")) return;
    setLoading(true); setError("");
    try { const response = await supplierFetch(`${apiBase}/imports/${id}/approve`, { method: "POST" }); const data = await response.json(); if (!response.ok) throw new Error(data.error); setMessage(`Atualização aprovada: ${data.created} novos, ${data.updated} atualizados e ${data.skipped} ignorados.`); await loadHistory(); if (preview) setPreview({ ...preview, status: "approved" }); } catch (caught) { setError(caught instanceof Error ? caught.message : "Não foi possível aprovar a atualização."); } finally { setLoading(false); }
  }

  return <section className="admin-panel supplier-import-panel"><div className="supplier-import-intro"><div><span className="admin-eyebrow">FORNECEDOR / TYROS CELL</span><h2>Importação de Tabelas de {isBattery ? "Baterias" : "Frontais"}</h2><p>Envie o Excel original da Tyros Cell. O sistema interpreta modelos, qualidades e custos, mas não altera o catálogo público antes da sua aprovação.</p></div><div className="supplier-formula"><span>Fórmula atual</span><strong>Y = (X × 2) + R$ 30</strong><small>X é o custo importado; Y é o preço estimado ao cliente.</small></div></div><div className="admin-grid admin-grid--workspace"><div className="admin-card"><div className="admin-card__head"><div><span className="admin-eyebrow">1 / ENVIAR</span><h2>Tabela de {isBattery ? "baterias" : "telas"}</h2></div><UploadCloud size={21} /></div><label className="supplier-dropzone"><input type="file" accept=".xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel" onChange={(event) => setFile(event.target.files?.[0] ?? null)} />{file ? <><strong>{file.name}</strong><small>{(file.size / 1024).toFixed(1)} KB · pronto para leitura</small></> : <><strong>Selecionar arquivo Excel</strong><small>Aceita .xlsx e .xls · máximo 25 MB</small></>}</label><button className="admin-button admin-button--primary" disabled={!file || loading} onClick={upload}>{loading ? "Lendo arquivo..." : "Importar e gerar prévia"}</button>{message && <p className="supplier-success"><CheckCircle2 size={15} /> {message}</p>}{error && <p className="admin-form-error">{error}</p>}</div><div className="admin-card"><div className="admin-card__head"><div><span className="admin-eyebrow">2 / HISTÓRICO</span><h2>Importações de {isBattery ? "baterias" : "frontais"}</h2></div><strong className="admin-stat">{imports.length}</strong></div>{imports.length ? <div className="admin-review-list">{imports.map((item) => <article className="admin-review" key={item.id}><div className="admin-review__top"><strong>{item.fileName}</strong><span className={item.status === "approved" ? "status status--live" : "status"}>{item.status === "approved" ? "Aprovada" : "Prévia"}</span></div><small>{new Date(item.createdAt).toLocaleString("pt-BR")} · {item.validRows} válidos · {item.invalidRows} inválidos · {item.duplicateRows} duplicados</small><div className="admin-review__actions"><button onClick={() => inspect(item.id)}>Conferir dados</button>{item.status !== "approved" && <button className="admin-button--mini-primary" onClick={() => approve(item.id)}>Aprovar atualização</button>}</div></article>)}</div> : <div className="admin-empty"><FileText size={24} /><h3>Nenhuma importação ainda</h3><p>O histórico será criado a partir do primeiro Excel enviado.</p></div>}</div></div>{preview && <div className="admin-card supplier-preview"><div className="admin-card__head"><div><span className="admin-eyebrow">3 / CONFERÊNCIA</span><h2>Prévia: {preview.fileName}</h2><p>{preview.rowsTotal} modelos · {preview.validRows} custos válidos · {preview.invalidRows} inválidos · {preview.duplicateRows} duplicidades</p></div><span className={preview.status === "approved" ? "status status--live" : "status"}>{preview.status === "approved" ? "Aprovada" : "Aguardando aprovação"}</span></div><div className="supplier-stat-row"><span>Marcas encontradas: <strong>{preview.brands?.join(", ") || "ver planilha"}</strong></span><span>Registros exibidos: <strong>{preview.preview.length}</strong></span></div><div className="admin-table-wrap"><table className="admin-table supplier-table"><thead><tr><th>Aba</th><th>Marca</th><th>Modelo</th><th>Qualidade</th><th>Custo privado</th><th>Preço final estimado</th><th>Validação</th></tr></thead><tbody>{preview.preview.slice(0, 120).map((row, index) => <tr key={`${row.sheetName}-${row.rowNumber}-${index}`}><td>{row.sheetName}</td><td>{row.brand}</td><td><strong>{row.model}</strong></td><td>{row.quality || "Não informado"}</td><td>{row.supplierCost === null ? "—" : `R$ ${row.supplierCost.toFixed(2)}`}</td><td>{row.estimatedPrice === null ? "—" : `R$ ${row.estimatedPrice.toFixed(2)}`}</td><td><span className={row.valid && !row.issue ? "status status--live" : "status"}>{row.valid && !row.issue ? "Válido" : row.issue || "Revisar"}</span></td></tr>)}</tbody></table></div>{preview.status !== "approved" && <button className="admin-button admin-button--primary" disabled={loading} onClick={() => approve(preview.importId)}>Aprovar atualização desta prévia</button>}</div>}</section>;
}
